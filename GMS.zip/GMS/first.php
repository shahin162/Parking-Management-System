
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Welcome | GMS </title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/custom.min.css" rel="stylesheet">
</head>


<br>

<div style="color: white" class="separator">
               
 
                <div class="clearfix"></div>
                <br/>
            </div>
            <div>
                <br>
                <h3 style="background: white "> </h3>>
               <input type="button" value="For Owner" class="homebutton" 
                    onClick="document.location.href='owner/login.php'" />
                 
            </div>

            <div>
                <br>
                <h3 style="background: white "> </h3>>
               <input type="button" value="For Renter" class="homebutton" 
                    onClick="document.location.href='renter/login.php'" />
                 
            </div>
            <div>
                <h1 style="padding-top: 100px;">Welcome to the GARAGE MANAHEMENT SYSTEM</h1>
            </div>

<body class="login" style="margin-top: -20px;">
	    <div class="login_wrapper">

            <section class="login_content" style="margin-top: -40px;">

            </section>






    
                
               
                     
               
            
           

  



</body>
</html>
