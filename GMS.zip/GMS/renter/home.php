<?php
include "connection.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Home | GMS </title>


    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/nprogress.css" rel="stylesheet">
    <link href="css/custom.min.css" rel="stylesheet">
</head>


<body class="">
<div class="container body">
    <div class="main_container">

        <div class="right_col" role="main">
            <div class="">
                <div class="page-title">
                    <div class="title_left">
                        <h3>Garage Space</h3>
                    </div>

                    <div class="title_right">
                        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                            <div class="input-group">

                <form name="form1" action="home.php" method="post">
                    
                    <input type="text" name="search" class="form-control" placeholder="Search for Garage...">
                    <span class="input-group-btn">
                    	<input class="btn btn-default submit" type="submit" name="submit1" value="Go!">     
                    </span>
                </form>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="clearfix"></div>
                <div class="row" style="min-height:500px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Search Result</h2>

                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">



        <?php

            if (isset($_POST["submit1"]))
            {

                $res=mysqli_query($link, "SELECT * FROM garage WHERE location LIKE '%$_POST[search]%'");
                                echo "<table class='table table-bordered'>";
                                echo "<tr>";
                                echo "<th>"; echo "Garage ID"; echo "</th>";
                                echo "<th>"; echo "Garage Name"; echo "</th>";
                                echo "<th>"; echo "Location"; echo "</th>";
                                echo "<th>"; echo "Address"; echo "</th>";
                                echo "<th>"; echo "Free Space Left"; echo "</th>";
       
                                echo "</tr>";
                                
                                while ($row=mysqli_fetch_array($res)) {
                                echo "<tr>";
                                echo "<td>"; echo $row["id"]; echo "</td>";
                                echo "<td>"; echo $row["garage_name"]; echo "</td>";
                                echo "<td>"; echo $row["location"]; echo "</td>";
                                echo "<td>"; echo $row["address"]; echo "</td>";
                                echo "<td>"; echo $row["free_space"]; echo "</td>";

                                echo "</tr>";
                                }
                                
                                echo "</table>";
            }

?>


<form id="Login" name="form2" action="home.php" method="post">


    <center>
            <input  type="text" name="usern" class="form-control" placeholder="User Name" required=""/><br><br>
            </center>
            </div>
            <center> 
            <input  type="Password" name="pass" class="form-control" placeholder="Password" required=""/><br><br>
            </center>
 
        <center>
            <input  type="text" name="id" class="form-control" placeholder="Garage ID" /><br><br>
            </div> 
            </center>
            <div>
                <center>
                     <input type="text" name="amount" class="form-control" placeholder="Amount" /><br>
 
            </div>
                </center>
                
               <center>
             <input class="btn btn-default submit" value="Confirm" type="submit" name="submit2">
 
        </center>
        </form>




<?php    
                         if(isset($_POST["submit2"]))
                         {
                                $res1 = mysqli_query($link, "SELECT * FROM garage WHERE id='$_POST[id]'");
                                while ($row=mysqli_fetch_array($res1)) {
 
        $total = $row["free_space"];
 
        $total2 = $total - 1;
         
        if ($total2 >= 0) {
 
 
 
               $sql = mysqli_query($link, "INSERT INTO payment VALUES ('', '$_POST[amount]', (SELECT ID from user where UserName='$_POST[usern]' and Password = '$_POST[pass]'), '$_POST[id]')");
 
                if ($sql === TRUE) {
 
                        $sql = mysqli_query($link, "UPDATE garage set free_space= free_space-1 where id='$_POST[id]'");
 
                    ?>
                <div class="alert alert-success col-lg-12 col-lg-push-0">
                Garage Booking successful, Thank you!!
 
                </div>
                <?php
                } else {
                    echo "<script>window.alert('Something went wrong!')</script>";
                }
 
 
                         }
 
                         else {
                    echo "<script>window.alert('Ticket not available!')</script>";
                }
 
 
                        }
                    }
                         
                     
 
                     
                 
                         
?>





                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->



        <!-- footer content -->
        <footer>
            <div class="pull-right">
                
            </div>
            <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
    </div>
</div>


<!-- jQuery -->
<script src="js/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="js/fastclick.js"></script>
<!-- NProgress -->
<script src="js/nprogress.js"></script>

<!-- Custom Theme Scripts -->
<script src="js/custom.min.js"></script>
</body>
</html>
